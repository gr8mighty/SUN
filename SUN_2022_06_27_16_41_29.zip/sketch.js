function setup() {
  createCanvas(400, 400);
  background('#87ceeb');
}

function draw() {
  noStroke();
  fill('#ffa500')
  circle(200,170, 300)
  
  noStroke();
  fill('#f9d71c')
  circle(200,170, 270)
  
  noStroke();
  fill('#fffd74')
  circle(200,170, 200)
  
textSize(20)
  fill('#fffd74')
text("good morning",260,380)
  
}